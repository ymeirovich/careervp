# CareerVP Redesign — Local Council Output

> **Local council** — these perspectives all come from Claude playing different
> roles, not from different AI vendors. Treat agreement as a shared starting
> point to pressure-test, not as independent confirmation.

Run: 2026-07-04 · 6 blind lenses (Data architect ×2 weight, Security, Reliability/SRE,
Cost/performance, Maintainability, Delivery risk), each reasoning only from
`context-pack.md`, blind to the others.

---

## 🗳️ Lens: Data architect (×2 weight)

**Assessment of the documented plan**

- The `core` PK/SK model is directionally correct but sequenced too late and framed as one flagship migration. `PK=USER#{cognito_sub}` + `SK=APP#{app_id}#{ARTIFACT|STATUS}` is the right item-collection shape for the actual co-read pattern (§6 Phase 3, §5 "co-read entities as one item collection — FAIL"). But bundling four distinct wins (kill env-var precedence, retire `userEmail` PK, unify CV PK, fix TTL/orphan) into a single expand→contract migration is the highest-blast-radius work in the plan handed to a solo dev — exactly the big-bang the constraints (§7) say to penalize.
- Phase 0's `RETAIN` gate is right and non-negotiable — §4 CRITICAL correctly names `RemovalPolicy.DESTROY` as the thing that "makes any in-place migration unsafe." No dissent.
- Mis-sequenced: the cheap, reversible, single-table-independent data fixes are buried behind Phase 3. Connection reuse (E1), Scan elimination (E5/E6), the `TransactWriteItems` gap (E7), and dropping the dual-schema write (E2) do not require the `core` migration and each is independently shippable.
- Unverified assumption that undermines Phase 3 scope: §8 Q1/Q2 admit the team cannot statically determine which schema is deployed where, nor whether a `pk/sk` write to a `userId/cvId` table raises `ValidationException` at runtime. Phase 3 rests on facts the pack says are unknown — resolve before committing, not "measured during."
- Under-scoped: GSI `ALL` projection is a per-index change (add a minimal-projection GSI, cut reads over) that doesn't need the table redesign — needlessly gated behind the flagship.
- Correctly de-scoped: refusing RAG/OpenSearch (~$345/mo) is right — key-based retrieval suffices at <10k and it would blow the margin math for zero access-pattern need.

**Findings**

- **F1 — Connection reuse (E1):** module-level cached boto3 resource + memoized `Table` by name. §3 E1. Importance High · LOE S · Difficulty Low. Depends on: nothing (smallest safe data slice). Contract: n.
- **F2 — Eliminate Scans (E6/E5):** point-lookup Scans → `Query` on GSI; reconciliation Scan → sparse status/renewal-date GSI reading O(active) not O(all users). §3 E6, §5. Importance High · LOE M · Difficulty Med. Depends on: F5 governs new GSIs. Contract: n.
- **F3 — Atomicity for E7:** collapse ensure-map-then-set into one `update_item` (`if_not_exists`); reserve `TransactWriteItems` for genuine cross-item invariants; preserve E8 conditional-claim as template. §3 E7. Importance High · LOE S–M · Difficulty Med. Contract: n.
- **F4 — Stop dual CV write (E2/E3):** add Streams drift metric first, stop writing legacy `pk/sk` alias once legacy read path is cold for a full 90d TTL window, then remove fallback. §3 E2/E3. Importance High · LOE M · Difficulty Med. Depends on: drift metric (B1), F1. Contract: n.
- **F5 — Minimal-projection GSIs:** parallel `KEYS_ONLY`/`INCLUDE` GSI → cut over → drop `ALL`. Must run after Phase 0 nested-stack decomposition (CFN ceiling). §2a, §4 HIGH. Importance Med · LOE M · Difficulty Med. Contract: n.
- **F6 — Retire `userEmail` PK on `knowledge`:** standalone small expand→…→contract to `PK=USER#{cognito_sub}`; proves the migration playbook on a low-traffic TTL'd table. §2a, §4 HIGH. Importance Med · LOE M · Difficulty Med. Contract: n (flag y only if a client passes email as lookup key — unverified).
- **F7 — Split the 1128-LOC god-class + single key authority:** strangler split one entity at a time; single `resolve_table()` replaces the env-var precedence chain so reader/writer can't diverge. This is the true prerequisite for Phase 3. §2b, §2c, §5. Importance High · LOE L · Difficulty Med. Precedes Phase 3. Contract: n.
- **F8 — Eliminate VPR full-version read (E4):** version in SK, `ScanIndexForward=False, Limit=1` instead of paginating all versions to compute max — on the 74%-spend artifact's write path. §3 E4. Importance Med · LOE M · Difficulty Med. Contract: n.
- **F9 — Schema-enforced TTL + orphan/`_is_stale` cleanup:** set TTL attribute at infra level for ephemeral tables; fix orphan row + `_is_stale` latent loop. §2a, §4 MED, §8 Q3. Importance Low–Med · LOE S · Difficulty Low. Contract: n.

**Blind spots**

- **B1** — No drift-measurement instrument exists, yet the whole plan depends on one. Build the Streams-fed drift metric in Phase 0/1 (cheap: `jobs`/`artifacts` already have `NEW_AND_OLD` streams); it also answers §8 Q1/Q2.
- **B2** — No `BatchGetItem`/`BatchWriteItem` audit. E5's 6 sequential round-trips could collapse to `BatchGetItem` today, independent of `core`.
- **B3** — On-demand + a full-table Scan is the one infra line that doesn't stay a rounding error (per-RCU, uncapped). Fixing F2 matters more on on-demand.
- **B4** — No 400KB item-size rule stated for the `core` collection: artifacts+statuses must stay individual items (ranged SK), never a merged blob.
- **B5** — `llm_cache`/`company_research_cache` key design + hit-rate is the actual margin lever (§7) and the redesign says nothing about it — worth more to >70% margin than any GSI projection change.

**Dissent**

- Dissent from treating Phase 3 (`core`) as the flagship a solo dev should aim for. At <10k the performance payoff is marginal; the real value is maintainability/correctness, and most of that is captured by F7 + F4 + F6 + F8 **without** the full table migration. For a solo dev the big-bang `core` cutover is riskier than its payoff at this scale.
- Expect the cost lens to over-rate GSI `ALL` (F5): rank Med, not High.
- Expect the reliability lens to under-rate E4 (a latent latency/cost cliff, not just a smell).
- Dissent on sequencing `userEmail` retirement inside Phase 3 — do it as an isolated playbook-proving migration.

---

## 🗳️ Lens: Security

**Assessment of the documented plan**

- Phase 1 is correctly scoped and prioritized as the first value wave; the disagreement is ordering within/around it, not the item set.
- Mis-sequenced dependency: `AUTHORIZER_DISABLED=true` is not in the Phase 1 list. Removing the header fallback does nothing on `cv_tailoring_func` if the authorizer is entirely bypassed — a one-line flag flip that belongs first; likely the cheapest CRITICAL fix in the plan.
- Phase 0 (`RETAIN`) is a security control (personal-data durability), not just a migration gate — correctly first.
- Unverified assumption in the `get_job` fix: `jobs` PK is `job_id` (not user-scoped); the fix is "compare item owner to JWT subject and 404 on mismatch," not "add a partition-key check."
- Under-scoped: E10 (JWT plaintext key) is treated as a config move; the plan never asks whether the self-managed RS256 path should exist at all — two auth systems is the root cause.
- Correctly de-scoped, and endorsed: no CMK, no residency controls, no field-level PII encryption. AWS-owned keys + PITR are adequate with no GDPR duty at <10k.

**Findings**

- **Auth bypass (`x-user-id` + `AUTHORIZER_DISABLED`):** delete the header branch (401 when JWT absent); remove `AUTHORIZER_DISABLED` entirely. §4 CRITICAL, §5. Importance **Critical** · LOE S · Difficulty Low. Ship first. Contract: **y** (clients relying on `x-user-id` / un-authorized `cv_tailoring` route get 401 — flag frontend).
- **IDOR `get_job`:** compare stored owner to JWT subject, 404 on mismatch; sweep sibling handlers (artifacts/cvs/applications). §4, §2a. Importance **Critical** · LOE M · Difficulty Low. Depends on: auth-bypass fix. Contract: n.
- **JWT plaintext key (E10):** pass SSM path resolved at runtime (like the Anthropic key) or Secrets Manager; rotate after. §3 E10, §4 HIGH. Importance High · LOE S · Difficulty Low. Depends on: decide if self-managed JWT survives. Contract: n.
- **Wildcard IAM + shared role:** narrow KMS/AppConfig to specific ARNs (S/low-risk); split shared role incrementally, highest-privilege Lambdas first (billing/cv_tailoring/secrets). DynamoDB/S3 grants already least-privilege → High, not Critical. §4 CRITICAL nuance, §5. Importance High · LOE L · Difficulty Med. Contract: n.
- **CV bucket CORS `*` + unversioned:** restrict CORS to known origins; enable versioning (personal-data durability). §4 HIGH, §6. Importance High(CORS)/Med(versioning) · LOE S · Difficulty Low. Contract: n backend; flag frontend if a preview/staging origin uploads CVs.
- **`userEmail` PK (`knowledge`):** endorse the plan — fix on the Phase 3 contract; do NOT pull forward. Security payoff is modest (authenticated-derived identifier, not a secret; no GDPR). Importance **Med** (security lens) · LOE L · Difficulty High. Contract: n.
- **WAF prod-only:** keep WAF-all-envs but Med priority — the 2 req/s throttle (E9) already self-limits brute-force; sequence WAF with the throttle raise. Importance Med · LOE S · Difficulty Low. Contract: n.
- **Cognito policy:** raise min length to 12, enable optional (not enforced) TOTP MFA. Do not gold-plate to mandatory MFA. Importance Med · LOE S · Difficulty Low. Contract: n (flag copy change).

**Blind spots**

- Two coexisting auth systems (Cognito + self-managed RS256) is the root cause of `x-user-id`, `AUTHORIZER_DISABLED`, and E10. Add an explicit decision item: can the self-managed JWT path be retired in favor of Cognito-only? (makes E10 vanish).
- **Personal-data export/delete is entirely absent from §4 and §6**, yet §7 requires it. A delete must fan out across `users`/`cvs`/`applications`/`gap_responses`/`knowledge`/`artifacts` + S3 — and today the §2c three-schema defect means a delete can't even reliably find all of a user's rows. Becomes tractable only after Phase 3 unifies keys.
- No secret-exposure detection on git history — gitleaks is forward-looking; assume-breach says scan history and rotate the JWT key now.
- PITR 7 days on personal-data stores: a corruption/bulk-delete found on day 8 is unrecoverable. Consider 35d (cheap), especially once account-delete tooling exists.

**Dissent**

- `userEmail`-key retirement is only Med from the security lens (against catalog HIGH) — keep it in Phase 3 for data-model reasons, don't let it jump the queue as a security fix.
- Reject any push toward CMK / mandatory MFA / field-level PII encryption — textbook gold-plating the constraints forbid.
- The highest-ROI security fix is the cheapest one: ship `AUTHORIZER_DISABLED` + `x-user-id` removal in isolation on day one, ahead of Phase 0's stack decomposition — it's additive code needing no CFN headroom.

---

## 🗳️ Lens: Reliability / SRE

**Assessment of the documented plan**

- Sequencing is largely right (RETAIN first is correct) but Phase 2 is under-scoped and mis-ordered: visibility-timeout ≥6× and `ReportBatchItemFailures` are pure duplicate-spend/silent-loss stoppers, S/Low, zero-dependency — they should move into the Phase 0/1 window, not wait behind security work.
- Idempotency is placed in Phase 1 but scoped only to billing; with visibility-timeout==1× and `retry_attempts=0`, the AI workers also re-run and burn duplicate tokens — idempotency is broader than the money path.
- Unverified assumption that alarms will notify someone: §8 Q7 says SNS topics may have no subscribers. Building alarms on an unsubscribed topic manufactures false confidence.
- `retry_attempts=0` has no explicit remediation step; turning retries on is unsafe until idempotency + `batchItemFailures` + visibility timeout are fixed — a real ordering constraint the plan leaves implicit.
- `max_concurrency`, visibility timeout, DLQ `maxReceiveCount`, and retry count are one coupled tuning problem, listed as four separate items.
- E7 atomicity and the good E8 pattern are addressed only inside Phase 3 — over-coupled; partial-state risk is a today defect fixable on the existing schema.

**Findings**

- **Visibility timeout ≥6×:** per-queue CDK one-liner; protects the token margin lever with near-zero blast radius. §4 CRITICAL, §5. Importance **Critical** · LOE S · Difficulty Low. Precede re-enabling retries. Contract: n.
- **Idempotency (billing + workers):** wire `@idempotent` on `billing_lambda` keyed by Stripe event id (table already exists); extend to `*_worker` keyed on business job/app id. §4 CRITICAL, §2a. Importance **Critical** · LOE S (billing)/M (workers) · Difficulty Low. Contract: n.
- **`ReportBatchItemFailures` on all 4 workers:** + enable the function-response type; land with DLQ wiring. §4 CRITICAL, §5. Importance **Critical** · LOE S · Difficulty Low. Contract: n.
- **Wire DLQs + `maxReceiveCount` + re-enable `retry_attempts`:** only after visibility ≥6× + batchItemFailures + worker idempotency. §4 CRITICAL/HIGH, §5. Importance **Critical** · LOE S/M · Difficulty Med. Contract: n.
- **`max_concurrency` 3–5 on AI workers:** one coupled tuning exercise with the above. §4 HIGH, §6. Importance High · LOE S · Difficulty Low. Contract: n.
- **E7 non-atomic write:** single `update_item` (`if_not_exists`) or `TransactWriteItems`; fix on existing schema, decouple from Phase 3; de-risks stale-`RUNNING` (§8 Q4). §3 E7, §5. Importance High · LOE S · Difficulty Low/Med. Contract: n.
- **Verify SNS subscribers before any new alarm:** add ≥1 subscription per topic + CI assertion. §4 MED, §8 Q7. Importance High · LOE S · Difficulty Low. Must precede alarm work. Contract: n.
- **Monitoring coverage:** DLQ-depth alarms + money/AI-worker error alarms first; raise log retention 1d→≥30d. §4 MED, §6. Importance High · LOE M · Difficulty Low. Depends on: SNS-subscriber fix, DLQ wiring. Contract: n.
- **`RemovalPolicy.DESTROY`→`RETAIN` + deletion protection:** 10 tables + 6 buckets; `cdk import`; verify PITR on. §2a, §4 CRITICAL, §6. Importance **Critical** · LOE M · Difficulty Med. Root prerequisite. Contract: n.

**Blind spots**

- No dead-letter **replay** path specified — a DLQ you can't drain is just slower loss; need an idempotent redrive runbook.
- Step Functions STANDARD + `waitForTaskToken` failure modes unaddressed — no heartbeat/timeout on the task token; a worker dying after consuming the SQS message but before `SendTaskSuccess` can strand an execution forever (likely the mechanism behind stale `RUNNING`, §8 Q4).
- `jobs` TTL (~24h) can expire in-flight async job state underneath a stuck/retried/DLQ-parked worker — a latent data-loss vector distinct from "TTL never-expires."
- PITR 7d < the incident-detection window created by 1-day logs + unsubscribed alarms.
- Stream consumers are at-least-once; if the drift/backfill consumer isn't idempotent, the very safety mechanism for Phase 3 is unreliable.

**Dissent**

- Dissent from deferring visibility-timeout and `batchItemFailures` to Phase 2 — ship in the Phase 0/1 window.
- Dissent from bundling E7 into Phase 3 — fixable in an afternoon on the current schema.
- Expect Data-architect/Maintainability to over-rate `core` vs its reliability payoff for a solo dev — Phase 3 is the highest-blast-radius item; the three-schema defect is more a correctness/maintainability problem than a reliability-at-scale one. Push Phase 3 later; ship every reliability quick-win first.
- Expect the Cost lens to under-weight visibility-timeout/idempotency — duplicate Sonnet/Haiku calls hit the token lever, the one cost that matters; they're cost items disguised as reliability items.

---

## 🗳️ Lens: Cost / performance

**Assessment of the documented plan**

- The plan's cost *labeling* is wrong: GSI `ALL` amplification, on-demand-vs-provisioned, and ARM64 are not margin items at <10k — they're latency/correctness items mislabeled as cost. The only true margin levers are AI token spend + cache hit-rate.
- Phase 5 is mis-sequenced within its own lens: it bundles ARM64 (near-zero value) with prompt-cache + Tavily truncation (the actual levers) in the last phase. Pull the two token levers forward.
- Biggest unverified assumption: §8 Q6 — VPR economics are UNMEASURED (2 Haiku samples, Sonnet estimated). Measurement must precede optimization; the plan sequences it last.
- Correctly keeps on-demand billing — no proven baseline exists; switching adds idle-cost risk for zero payoff.
- Under-scopes latency: E1/E4/E5/E6/E9 are latency/scale-ceiling problems scattered across phases; E1 and E9 are trivially fixable now.

**Findings**

- **Measure real token usage:** capture the Anthropic `usage` object as EMF dimensioned by artifact type + model; replace `len/4`. §8 Q6, §5. Importance High · LOE S · Difficulty Low. First cost action; gates all token findings. Contract: n.
- **Prompt-cache gaps:** cache breakpoints on stable prefixes of highest-spend prompts (VPR first). §4 MED, §5, §1. Importance High · LOE S · Difficulty Low. Depends on: measurement. Contract: n.
- **Tavily truncation:** cap search results to a bounded token budget before prompt assembly. §4 MED, §5. Importance High · LOE S · Difficulty Low. Contract: n.
- **boto3 reuse (E1):** latency win, not margin. §3 E1. Importance Med · LOE S · Difficulty Low. Contract: n.
- **Raise API throttle (E9):** above 2 req/s consistent with <10k; keep per-method throttles. §3 E9, §4 HIGH. Importance High · LOE S · Difficulty Low. Contract: n.
- **E4 bounded query:** version in SK; fold into `core` if it lands soon, else scoped interim fix (fires on every VPR write). §3 E4. Importance Med · LOE M · Difficulty Med. Contract: n.
- **E5 collapse round-trips:** one deterministic `cacheKey` lookup. §3 E5. Importance Med · LOE M · Difficulty Med. Contract: n.
- **E6 Scans:** point Scans → `GetItem`/`Query` now (Med); reconciliation Scan negligible $ at <10k, only fix if latency bites (Low). §3 E6. LOE M · Difficulty Med. Contract: n.
- **Keep on-demand; GSI `ALL` = latency/storage hygiene, not margin:** trim projections only when a GSI is rebuilt anyway. §2a, §5. Importance Low · LOE M · Difficulty Med. Contract: n.
- **Deprioritize ARM64:** saves ~20% of a rounding error; leave optional or drop. §4 MED, §5. Importance Low · LOE S · Difficulty Low. Contract: n.

**Blind spots**

- The plan optimizes token *inputs* but never sizes token *outputs* — §6's own note admits "cost is output tokens." No finding bounds `max_tokens`/output length per artifact; an oversized output budget is the most likely silent leak and is completely unexamined.
- No cost-per-application metric or anomaly guardrail until Phase 5, so the >70% margin is unmonitored — a prompt change or model swap can silently blow it.
- `llm_cache`/`company_research_cache` hit-rate is never measured; the §2c `ValidationException`→false-not-found bug may silently defeat cache reads (paying full token price on "cached" calls). Filed as data-model; it's also a token-leak.
- Duplicate AI spend from the reliability defects (visibility-timeout, no idempotency) is a cost leak — a duplicated VPR is a doubled ~$0.43; strengthens their priority.

**Dissent**

- Dissent from framing GSI `ALL`, Scan cost, and on-demand-vs-provisioned as margin work — rounding error inside a rounding error; matter only as latency/hygiene. Fold GSI projections into the `core` rebuild for free; never do them standalone for cost.
- Dissent from ARM64 and artifact compression on the cost track at all.
- Dissent from sequencing measurement last — it's High/S/Low and gates the correctness of every other cost claim; must be first, ahead of the flagship.

---

## 🗳️ Lens: Maintainability

**Assessment of the documented plan**

- Phase 0's stack decomposition is the correct, undervalued maintainability prerequisite — the 500-resource ceiling is a cognitive wall for a solo dev, and every Phase 1–2 change consumes scarce headroom. Rightly first.
- Under-scopes the god-class as a Phase-3-only concern — couples the most-touched liability to the riskiest migration. The seam (single table authority, connection reuse, typed repo boundary) is needed before and independent of the data-model change.
- Mis-sequenced: the env-var precedence chain and dead `DynamoDBStack`/stale spec are latent-defect/confusion sources left in place; the chain can silently route reader and writer to different tables today.
- Unverified assumption: that expand→…→contract is safely executable given the current test posture — the only stated test artifact is an autouse CI fixture that masks table-routing defects, the exact bug class being migrated.
- Right instinct wrong ordering on the `ValidationException`→false-not-found swallow — convert to log+metric+raise early so the migration is observable, not blind.
- Phase 3 as specced could hurt maintainability if half-done — needs an explicit reversible-checkpoint contract, not just "independently reversible steps," to avoid recreating the frozen-half-migration pathology.

**Findings**

- **TableRegistry — single table-name + boto3 authority (folds E1):** one pure module reads env vars + memoizes the boto3 resource; DAL calls `registry.table("artifacts")` by logical name. §2c, §3 E1, takeaway 6. Importance High · LOE S · Difficulty Low. Precedes Phase 1 handler work and all of Phase 3. Contract: n.
- **Convert silent `ValidationException`→log+metric+raise:** makes drift visible; the cheapest way to buy the "drift metric" the plan assumes. §2c, §3 E3. Importance High · LOE S · Difficulty Low. Depends on: TableRegistry. Contract: n (gate behind log-only mode; could turn a masked false-200 into a correct 500 in edge cases).
- **Delete dead `DynamoDBStack` + reconcile/retire `dynamodb_spec.yaml`:** two "sources of truth" with different keys/RemovalPolicy actively mislead migration authors. §2a trap, §8 Q1. Importance Med · LOE S · Difficulty Low. Contract: n.
- **Carve god-class along entity seams now (decoupled from `core`):** six thin per-entity modules delegating to TableRegistry, schema byte-for-byte unchanged, one entity per PR. §2b, takeaway 5. Importance High · LOE L · Difficulty Med. Depends on: TableRegistry. Precedes Phase 3. Contract: n.
- **Fix the autouse CI fixture masking table-routing:** per-logical-table fixtures (moto/local-DynamoDB) so a wrong-table resolution fails loudly. §4 LOW, §5. Importance High · LOE M · Difficulty Med. Contract: n.
- **Unify divergent error styles into a typed taxonomy** (`NotFound`/`SchemaDrift`/`Conflict`), mapped once at the handler edge. §2c, §3 E3. Importance Med · LOE M · Difficulty Low. Contract: n if status mapping preserved.
- **`CoreRepository` reversible-checkpoint contract:** migrate one entity at a time on the split repos; invariant "either fully on `core` or fully on legacy — never a persistent dual-write steady state"; per-entity flag + CI check. §6, takeaway 4. Importance High · LOE M · Difficulty Med. Gate on Phase 3. Contract: n.

**Blind spots**

- `api_storage_adapter.py` (229 LOC, "pure") is a **second** translation layer alongside the env-var chain — the "single key-builder" promise of Phase 3 is contradicted unless these collapse into one authority.
- Test-strategy debt is filed LOW but is the actual gating risk for a solo live migration — the plan's confidence in Streams drift is a production answer to what should first be a test-time correctness answer.
- `db_handler.py`'s `_SingletonMeta` hidden global state is a testability hazard — cross-test contamination that will make the improved suite flaky when it's most needed.
- The real maintainability metric is coupling fan-out: one CV save touches E1 + E2 + the env-var chain + the god-class on a single path — they must be fixed together as the first seam, not scattered across phases.

**Dissent**

- Dissent from folding the god-class split into Phase 3 — it's a low-risk high-relief mechanical change that should ship in Phase 0/1 and give the migration a per-entity surface.
- Expect Data-architect/Cost to over-rate the urgency of the physical single-table model — at <10k the correctness/change-safety wins come from a single key-builder + god-class split without the PK/SK collapse.
- `RETAIN`→ is also a maintainability enabler (makes expand→contract psychologically executable solo), not only a reliability guardrail — score it as both.

---

## 🗳️ Lens: Delivery risk

**Assessment of the documented plan**

- Phase 0 silently bundles two independent gates with different triggers: RETAIN blocks only migration (Phase 3); the 500-resource CFN ceiling blocks everything additive (Phases 1,2,4,5). The CFN ceiling is the true first mover.
- The expand→…→contract discipline is sound; the concern is whether one person can operate the drift-metric + per-cohort-canary machinery without a big-bang failure mode.
- Phase 1 is mislabeled "additive + canary" but `x-user-id` removal is breaking — it must be gated behind observed traffic, not just canaried.
- Unverified assumption that Phase 2 alarms will page someone (§8 Q7).
- Phase 3 rests on unresolved §8 Q1/Q2 that are load-bearing for reversibility — migrating an unmapped substrate is the biggest big-bang risk.
- The documented wave order is broadly correct; the flaw is intra-phase, not inter-phase.

**Findings**

- **CFN headroom = true Slice 0 (decouple from RETAIN):** ship nested-stack decomposition to <400/stack + CI gate; logical-ID-preserving, verify `cdk diff` zero replacements. §4 HIGH, §6 Phase 0. Importance **Critical** · LOE L · Difficulty High. But RETAIN must land first. Contract: n.
- **RETAIN + deletion-protection must precede the CFN decomposition itself:** stack surgery is where accidental deletion happens. §4 CRITICAL, §2a. Importance **Critical** · LOE S · Difficulty Low. True first slice. Contract: n.
- **Resolve §8 Q1/Q2 as a hard gate before ANY dual-write:** read-only prod recon → written table→schema→writer map + one-shot `cv_tailoring` write probe. §8 Q1/Q2, §2c. Importance **Critical** · LOE M · Difficulty Med. Contract: n.
- **`x-user-id` removal is breaking → log-only then remove behind flag:** split Phase 1 into truly-additive items vs breaking auth; emit a metric on every fallback hit, observe a bounded window, remove once zero. §4 CRITICAL, §6. Importance **Critical** · LOE M · Difficulty Med. Depends on: CFN headroom. Contract: **y** (flag frontend).
- **Verify SNS subscribers before Phase 2 alarms/auto-rollback:** auto-rollback on an unwatched topic proceeds on false confidence. §8 Q7, §4 MED. Importance High · LOE S · Difficulty Low. Contract: n.
- **Simplify Phase 3 machinery:** replace per-cohort-canary + Streams-drift with dual-write + an offline scan-and-compare reconciliation job (most tables lack Streams); flip read source per-entity behind a flag, one entity at a time. §6 Phase 3, §2a. Importance High · LOE XL · Difficulty High. Depends on: RETAIN, CFN, Q1/Q2. Contract: n (the Phase 4 `GET /me/bootstrap` is where contract change lands).
- **Smallest safe first migration slice — CV before app-artifacts:** CV is already dual-schema written/read (E2/E3) — a frozen half-migration already in the expand state; finish it first to prove the harness on the lowest-blast-radius entity. §3 E2/E3, §6. Importance High · LOE M · Difficulty Med. Contract: n.
- **Rollback runbook + rehearsed revert before the first migration deploy:** flag inventory, documented "flip read source back," PITR-restore steps tested once on a scratch table. §6, §7, §2a. Importance High · LOE S · Difficulty Low. Contract: n.

**Blind spots**

- The two Phase-0 gates are never sequenced against each other — ordering wrong is how a solo dev deletes a live table during the "safety" phase.
- Reversibility is asserted, not operationalized — no flag inventory, no restore drill.
- Drift-from-Streams assumes Streams that mostly don't exist (only 2 of 10 tables; `users` — a flagship target — has none).
- "Additive + canary" is an untested assumption about client dependence on the auth bypass.
- The CI resource-count threshold interacts with every later phase (DLQs + new table/GSI + versioned routes) — the plan doesn't budget remaining headroom across phases.

**Dissent**

- Dissent from treating Phase 3 as a single flagship deliverable — for a solo dev it's an XL/High big-bang wearing incremental clothing. Endorse only the CV-first, one-entity-at-a-time slice; the full app-artifact collapse stays last and gets re-evaluated for payoff after the cheaper wins land.
- Expect the Data-architect lens (×2) to over-rate the urgency of the full single-table model — from delivery risk it's the one item most likely to cause an irreversible incident for a solo operator. No part of `core` ships until CFN headroom + RETAIN + Q1/Q2 recon + rehearsed rollback + verified alarm path all exist.
- Expect Cost/Reliability to over-rate ARM64 / GSI trimming / prompt-cache on estimated savings — §8 Q6 economics are unmeasured; don't let a cost item preempt a reversibility/security slice.

---

# Synthesis — the council's combined deliverable

> Honest framing: all six lenses are the same model. Their agreement is a shared
> prior to stress-test, not cross-vendor corroboration. The value below is the
> spread of angles and the blind-spot coverage, and the places where the lenses
> genuinely pull against each other.

## 1. Deduplicated, ranked backlog

Ordered by Importance → Difficulty (risk) → LOE, tuned for solo incremental delivery.
Scores: **Imp** = Importance, **LOE** = S/M/L/XL, **Diff** = Difficulty. "Lenses" = which lenses raised it.

| # | Item | Imp | LOE | Diff | Depends on | Contract | Lenses |
|---|---|---|---|---|---|---|---|
| 1 | `RemovalPolicy.DESTROY`→`RETAIN` + deletion protection (10 tables, 6 buckets); `cdk import`; verify PITR | Critical | S | Low | — | n | DA, REL, MAINT, DEL |
| 2 | Remove `AUTHORIZER_DISABLED`; delete `x-user-id` fallback (log-only metric → remove behind flag) | Critical | M | Med | #1 | **y** | SEC, DEL |
| 3 | SQS visibility timeout ≥6× on all AI-worker queues | Critical | S | Low | — | n | REL, COST |
| 4 | `ReportBatchItemFailures` on all 4 workers + enable response type | Critical | S | Low | — | n | REL |
| 5 | Idempotency on billing (Stripe event id); table already exists | Critical | S | Low | — | n | REL, COST |
| 6 | IDOR: owner-vs-JWT check on `get_job` + sweep sibling handlers | Critical | M | Low | #2 | n | SEC |
| 7 | §8 Q1/Q2 read-only recon → table→schema→writer map + `cv_tailoring` write probe | Critical | M | Med | — | n | DEL, DA |
| 8 | CFN nested-stack decomposition <400/stack + CI resource-count gate | Critical | L | High | #1 | n | DEL, MAINT |
| 9 | Wire DLQs + `maxReceiveCount`; re-enable `retry_attempts` (after #3,#4,#5) + replay runbook | Critical | M | Med | #3,#4,#5 | n | REL, DEL |
| 10 | Verify/wire ≥1 SNS subscriber per alarm topic + CI assertion | High | S | Low | — | n | REL, DEL |
| 11 | Measure real Anthropic token usage (EMF) + cost-per-app metric + anomaly alarm | High | S | Low | — | n | COST |
| 12 | `max_concurrency` 3–5 on AI workers (coupled tuning with #3/#9) | High | S | Low | #3,#9 | n | REL |
| 13 | Raise API throttle above 2 req/s (E9); WAF all envs alongside | High | S | Low | — | n | COST, SEC, DEL |
| 14 | Idempotency extended to `*_worker` handlers (business job/app id) | High | M | Low | #5 | n | REL, COST |
| 15 | Prompt-cache breakpoints on VPR + high-spend prefixes | High | S | Low | #11 | n | COST |
| 16 | Bound Tavily input; bound artifact **output** `max_tokens` per type | High | S | Low | #11 | n | COST |
| 17 | TableRegistry: single table-name + boto3 authority (folds E1) | High | S | Low | — | n | MAINT, DA, COST |
| 18 | Convert silent `ValidationException`→log+metric+raise (the cheap drift metric) | High | S | Low | #17 | n (log-only first) | MAINT, DA |
| 19 | CV bucket CORS→known origins + enable versioning | High | S | Low | — | n (flag FE) | SEC |
| 20 | JWT key plaintext fix (SSM-path/Secrets Manager) **or** retire self-managed JWT path | High | S | Low | auth-path decision | n | SEC |
| 21 | Wildcard IAM narrowing (KMS/AppConfig → ARNs) [S]; shared-role split [L, incremental] | High | L | Med | #8 (headroom) | n | SEC |
| 22 | Split 1128-LOC god-class by entity (one PR each) onto TableRegistry | High | L | Med | #17 | n | DA, MAINT |
| 23 | Fix autouse CI fixture that masks table-routing (per-table fixtures) | High | M | Med | #17 | n | MAINT |
| 24 | E7 atomicity: single `update_item`/`TransactWriteItems` (fixes stale-`RUNNING` §8 Q4) | High | S | Med | — | n | DA, REL |
| 25 | Step Functions `waitForTaskToken` heartbeat/timeout (strands executions) | High | M | Med | — | n | REL (blind spot) |
| 26 | Log retention 1d→≥30d; DLQ-depth + money/AI-worker alarms | High | M | Low | #10 | n | REL |
| 27 | Rollback runbook + rehearsed revert (flag inventory, PITR-restore drill) | High | S | Low | #1 | n | DEL |
| 28 | Stop dual CV write (E2/E3) once legacy read cold for 90d TTL window | High | M | Med | #18 | n | DA |
| 29 | Personal-data export/delete capability (§7 requirement, absent from plan) | High | L | Med | key unification | y (new endpoints) | SEC (blind spot) |
| 30 | Eliminate point-lookup Scans (E6 `:127`,`:784`) → `GetItem`/`Query` | Med | M | Med | — | n | DA, COST |
| 31 | Delete dead `DynamoDBStack` + fix stale `dynamodb_spec.yaml` | Med | S | Low | #7 | n | MAINT |
| 32 | VPR E4: version-in-SK, `Limit=1` descending (on 74%-spend write path) | Med | M | Med | #22 | n | DA, COST |
| 33 | E5: collapse company-research to one `cacheKey` lookup | Med | M | Med | — | n | DA, COST |
| 34 | Retire `userEmail` PK on `knowledge` as standalone small migration | Med | M | Med | #7,#1,#27 | n | DA, SEC |
| 35 | `llm_cache`/`company_research_cache` hit-rate measurement; confirm §2c doesn't defeat cache | Med | M | Med | #11,#18 | n | DA, COST |
| 36 | Error taxonomy unification (`NotFound`/`SchemaDrift`/`Conflict`) | Med | M | Low | #22 | n | MAINT |
| 37 | Cognito: min length 12 + optional TOTP MFA | Med | S | Low | — | n (FE copy) | SEC |
| 38 | Collapse `api_storage_adapter` + env-var chain into the single authority | Med | M | Med | #17,#22 | n | MAINT (blind spot) |
| 39 | `jobs` ~24h TTL can expire in-flight state — guard/extend for active jobs | Med | S | Low | — | n | REL (blind spot) |
| 40 | `_SingletonMeta` hidden global state — remove for testability | Med | S | Low | #17 | n | MAINT (blind spot) |
| 41 | Schema-enforced TTL + orphan row + `_is_stale` cleanup (§8 Q3) | Low–Med | S | Low | — | n | DA |
| 42 | Secret-scan git history + rotate JWT key; consider PITR 7d→35d | Med | S | Low | — | n | SEC (blind spot) |
| 43 | `BatchGetItem` audit for remaining fan-out reads | Low–Med | M | Low | — | n | DA (blind spot) |
| 44 | GSI `ALL`→minimal projection — **only** piggybacked on a GSI rebuild, never standalone-for-cost | Low | M | Med | — | n | DA (Med) vs COST (Low) |
| 45 | `CoreRepository` reversible-checkpoint contract (one entity, no persistent dual-write) | High | M | Med | #22,#23,#18 | n | MAINT |
| 46 | **CV-first `core` migration slice** (smallest safe; already half-migrated) | High | M | Med | #45,#27,#7 | n | DEL, DA |
| 47 | Simplify `core` machinery: offline reconcile job vs Streams-drift; per-entity flag not per-cohort | High | XL | High | #45,#46 | n | DEL |
| 48 | **App-artifact collection collapse** (the flagship) — LAST; re-evaluate payoff first | Med* | XL | High | #45,#46,#47 | n | DA/REL/MAINT/DEL dissent |
| 49 | `GET /me/bootstrap` aggregate + versioned routes (Phase 4) | Med | M | Med | #48 | **y** | (plan) |
| 50 | ARM64; keep on-demand (do **not** move to provisioned) | Low | S | Low | — | n | COST (drop/defer) |

\* #48 Importance is deliberately **downgraded to Med** by the council relative to the plan's "flagship/HIGH" framing — see §3.

## 2. Recommended wave sequencing (and where it differs from documented Phase 0–5)

- **Wave 0 — Gates (must precede everything):** #1 RETAIN → #8 CFN headroom (RETAIN *first*, then stack surgery) · #10 SNS subscribers · #7 schema recon · #11 token measurement.
- **Wave 1 — Cheap correctness/safety config fixes (ship immediately):** #2 auth · #3 visibility timeout · #4 batchItemFailures · #5 billing idempotency · #6 IDOR · #12 max_concurrency · #13 throttle+WAF · #14 worker idempotency · #9 DLQ/retry · #19 CORS/versioning · #20 JWT key · #26 logs/alarms · #21 (wildcard narrowing part).
- **Wave 2 — Token margin levers (the actual >70% margin):** #15 prompt-cache · #16 Tavily+output bounds · #35 cache hit-rate.
- **Wave 3 — DAL seams & reliability hardening (decoupled from `core`):** #17 TableRegistry · #18 ValidationException visibility · #22 god-class split · #23 CI fixture · #24 E7 · #25 task-token timeout · #30 point Scans · #31 dead stack · #36 error taxonomy · #38 adapter collapse · #40 SingletonMeta · #21 (role split).
- **Wave 4 — Targeted standalone data-model fixes:** #28 stop dual CV write · #32 VPR E4 · #33 E5 · #34 userEmail · #39 jobs TTL · #41 TTL/orphan · #42 secret-scan/PITR · #43 BatchGet · #44 GSI projection (opportunistic).
- **Wave 5 — `core` migration (deferred, decomposed, gated):** #27 rollback drill · #45 checkpoint contract · #46 CV-first slice · #47 simplified machinery · #29 export/delete · #48 app-artifact collapse (LAST, re-evaluate).
- **Wave 6 — API/compute & polish:** #49 bootstrap/versioning · #50 ARM64/on-demand.

**Where this differs from the documented Phase 0–5:**
1. **Split Phase 0 into ordered gates** — RETAIN *before* the CFN stack surgery (surgery is where accidental deletion happens); the plan bundles them.
2. **Pull the S/Low config fixes forward into Wave 1** — the plan scatters visibility-timeout/batchItemFailures into Phase 2 and buries `AUTHORIZER_DISABLED` in a Phase 1 bullet. These stop active silent data loss + duplicate token spend *today*.
3. **Elevate token-margin work from Phase 5 to Waves 1–2** and make **measurement a Wave-0 prerequisite** (§8 Q6) — the plan sequences the only real margin levers last.
4. **Decouple god-class split + TableRegistry + drift-visibility from Phase 3 into Wave 3** — low-risk seams that make every later phase cheaper; the plan folds them into the riskiest phase.
5. **Add a hard schema-recon gate (§8 Q1/Q2) before any dual-write** — the plan assumes the mapping is knowable from code; §8 says it isn't.
6. **Demote and decompose Phase 3** — CV-first slice + offline reconcile; hold the full app-artifact collapse until last and re-evaluate whether it's needed at all.
7. **Add items the plan omits entirely:** personal-data export/delete, Step Functions task-token timeout, DLQ replay runbook, rehearsed rollback, SNS subscriber verification, output-token bounding, cost-per-app monitoring, `jobs`-TTL in-flight expiry, dead-stack deletion, `api_storage_adapter` collapse.

## 3. Consensus vs. disagreement

**Genuine convergence (stress-test, don't trust as corroboration):**
- RETAIN first is non-negotiable (all four lenses that touch infra).
- The cheap config fixes are under-prioritized by being placed in later phases and should ship first.
- The god-class split should be decoupled from and precede Phase 3.
- **The full `core` collapse is over-scoped/over-prioritized for a solo dev at <10k** — 4 of 6 lenses (including the ×2 Data-architect) independently landed here.

**Real disagreements:**
- **GSI `ALL` projection:** DA (×2) = Med (write-amplification hygiene); COST = Low ("doesn't move the margin needle"). *Resolution:* latency/storage-hygiene, opportunistic only (item #44).
- **`userEmail` key:** catalog = HIGH; both DA and SEC downgrade to **Med**. *Resolution:* standalone small migration (#34), not a Phase-1 security jump-ahead.
- **`x-user-id` timing:** SEC = ship day one (cheapest critical); DEL = it's *breaking*, gate behind observed traffic. *Resolution:* not a real conflict — top priority (SEC) via log-only→remove mechanism (DEL). Encoded in #2.
- **E4 (VPR full-version read):** DA says the others under-rate it (unbounded, on the 74%-spend write path); COST = Med. *Resolution:* Med but flagged as a latent cliff (#32).

**Notable — the double-weight lens does NOT defend the flagship.** The Data-architect (×2) lens, which one would expect to champion single-table, explicitly argues most of `core`'s value is captured by the god-class split + stop-dual-write + userEmail + E4 fixes **without** the big migration. So the ×2 weight *reinforces* the "decompose Phase 3" position rather than opposing it.

## 4. Top risks & prerequisites

**Non-negotiable gates (in order):**
1. **RETAIN + deletion protection** before any stack-topology change or migration.
2. **CFN headroom** (nested-stack <400 + CI gate) before any additive work — but *after* RETAIN.
3. **§8 Q1/Q2 schema recon** (table→schema→writer map) before any dual-write.
4. **SNS subscriber verification** before trusting any alarm or canary auto-rollback.
5. **Token measurement** before any token-optimization decision (§8 Q6).
6. **Rehearsed rollback + drift-visibility** before the first migration slice.

**Single smallest safe first slice:** **#1 — the `RETAIN` flip.** S/Low, fully reversible, and the gate that makes every subsequent change safely reversible for a solo dev. In parallel (different resources, week one): **#2 — remove `AUTHORIZER_DISABLED` + `x-user-id` log-only metric**, the highest-severity-closed-per-effort. If forced to pick one: RETAIN.

## 5. Open questions (§8) that block a recommendation

- **Q1 (which schema deployed where)** — BLOCKS Phase 3 dual-write. Resolve via read-only recon (#7).
- **Q2 (`cv_tailoring` write target `ValidationException`)** — BLOCKS CV-migration correctness. Resolve via runtime probe (#7).
- **Q6 (VPR economics unmeasured — 2 Haiku samples)** — BLOCKS every cost-ranked decision and the Sonnet-5 pilot. Resolve via token measurement (#11) before Wave 2.
- **Q7 (SNS subscribers)** — BLOCKS trusting alarms/auto-rollback. Resolve in Wave 0 (#10).
- **Q4 (stale `RUNNING`)** — tied to the Step Functions task-token-timeout blind spot; model `chain_execution_status` as first-class state (#25).
- **Q3 (`_is_stale`)** — minor; fold into #41.
- **Q5 (`jobs`/`applications` unified or subsumed by `core`)** — informs Wave-5 scope; not blocking near-term. Defer until #46 proves the harness.

**What the whole council may be missing (same-model caveat):** every lens accepted the §7 constraints and the context pack's characterization of the code without challenge — appropriate for hard constraints, but note the pack itself flags (§8 Q1) that static reading can't fully resolve the deployed substrate, so the entire analysis rests on a partly-unknown base. The strongest emergent, under-stated conclusion: **the big `core` migration may never be worth doing** — its correctness/maintainability payoff is largely separable and capturable through the cheaper Wave-3 seams, so treat #48 as a hypothesis to re-justify after Waves 0–4, not a committed deliverable.
